% Main program to run the experiments and plot the graphics
% No parametes necessary

clear all;
close all;

rng(0); %Change to choose seed

for test_case=1:4 % Compute the four cases and generate datafiles
   example_ncomm ;
end


plot_data_tight ; %Read datafiles and make the plots
