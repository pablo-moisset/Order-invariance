drange = 5:100 ; % Species diversity range
replicates = 15 ;

Conn = 0.2 ; % Connectance
CON = 1 ;    % NOT USED
TwoLayers = 1 ; % 1 for bipartite networks. This is what T&F assumed

Hill = 1 ; % Hill coefficient
Norm = 0 ; % 0: do not normalize c_i's. 1: normalize
Comp = 1 ; % 1: interspecies competition. 0: no competition

%figure ;

if test_case==1
subplot(2,2,1)
all_p = zeros(drange(end),replicates) ;
all_pp = all_p ;
all_ph = all_p ;
all_Bio = all_p ; 
plant_Bio = all_p ;
herb_Bio = all_p ;

for r=1:replicates
   r %print replica number
   for S=drange
       [p, pp, ph, T, Y] = test_persistence(S, Hill, Norm, Comp, Conn, CON, TwoLayers, 0, 0) ;
       all_p(S,r) = p ;
       all_pp(S,r) = pp ;
       all_ph(S,r) = ph ;
       all_Bio(S,r) = sum(Y(end,:)) ;
       plant_Bio(S,r) = sum(Y(end,1:round(S/2))) ;
       herb_Bio(S,r) = all_Bio(S,r) - plant_Bio(S,r) ;
   end
end
save(sprintf('H%.1fN%dC%dc%.2f.B1.mat', Hill, Norm, Comp, Conn), ...
    'all_p', 'all_pp', 'all_ph', 'all_Bio', 'plant_Bio', 'herb_Bio') ;
yyaxis left
plot(drange,all_p(drange,:),'bo') ;
hold on
plot(drange,mean(all_p(drange,:),2)) ;
hold on
ylabel('species persistence') ;
axis([min(drange) Inf 0 1.0]) ;

yyaxis right
plot(drange,all_Bio(drange,:),'ro') ;    
hold on
if TwoLayers
    plot(drange,mean(plant_Bio(drange,:),2),'--') ;    
    hold on
    plot(drange,mean(herb_Bio(drange,:),2),'-.') ;    
    hold on
end
plot(drange,mean(all_Bio(drange,:),2)) ;    
axis([min(drange) Inf 0 Inf]) ;
ylabel('Total biomass') ;
xlabel('species richness') ;

title(sprintf('Hill=%d, Norm=%d, Comp=%d, Conn=%4.2f', Hill, Norm, Comp, Conn)) ;
end


if test_case==2
Hill = 1 ;
Norm = 0 ;
Comp = 0 ;

subplot(2,2,2)
all_p = zeros(drange(end),replicates) ;
all_pp = all_p ;
all_ph = all_p ;
all_Bio = all_p ; 
plant_Bio = all_p ;
herb_Bio = all_p ;

for r=1:replicates
    r
    for S=drange
       [p, pp, ph, T, Y] = test_persistence(S, Hill, Norm, Comp, Conn, CON, TwoLayers, 0, 0) ;
       all_p(S,r) = p ;
       all_pp(S,r) = pp ;
       all_ph(S,r) = ph ;
       all_Bio(S,r) = sum(Y(end,:)) ;
       plant_Bio(S,r) = sum(Y(end,1:round(S/2))) ;
       herb_Bio(S,r) = all_Bio(S,r) - plant_Bio(S,r) ;
    end
end
save(sprintf('H%.1fN%dC%dc%.2f.B1.mat', Hill, Norm, Comp, Conn), ...
    'all_p', 'all_pp', 'all_ph', 'all_Bio', 'plant_Bio', 'herb_Bio') ;
yyaxis left
plot(drange,all_p(drange,:),'bo') ;
hold on
plot(drange,mean(all_p(drange,:),2)) ;
hold on
ylabel('species persistence') ;
axis([min(drange) Inf 0 1.0]) ;

yyaxis right
plot(drange,all_Bio(drange,:),'ro') ;    
hold on
if TwoLayers
    plot(drange,mean(plant_Bio(drange,:),2),'--') ;    
    hold on
    plot(drange,mean(herb_Bio(drange,:),2),'-.') ;    
    hold on
end
plot(drange,mean(all_Bio(drange,:),2)) ;    
axis([min(drange) Inf 0 Inf]) ;
ylabel('Total biomass') ;
xlabel('species richness') ;

title(sprintf('Hill=%d, Norm=%d, Comp=%d, Conn=%4.2f', Hill, Norm, Comp, Conn)) ;
end

if test_case==3

Hill = 1 ;
Norm = 1 ;
Comp = 1 ;

%figure ;
subplot(2,2,3)
all_p = zeros(drange(end),replicates) ;
all_pp = all_p ;
all_ph = all_p ;
all_Bio = all_p ; 
plant_Bio = all_p ;
herb_Bio = all_p ;

for r=1:replicates
    r
    for S=drange
       [p, pp, ph, T, Y] = test_persistence(S, Hill, Norm, Comp, Conn, CON, TwoLayers,0, 0) ;
       all_p(S,r) = p ;
       all_pp(S,r) = pp ;
       all_ph(S,r) = ph ;
       all_Bio(S,r) = sum(Y(end,:)) ;
       plant_Bio(S,r) = sum(Y(end,1:round(S/2))) ;
       herb_Bio(S,r) = all_Bio(S,r) - plant_Bio(S,r) ;
    end
end
save(sprintf('H%.1fN%dC%dc%.2f.B1.mat', Hill, Norm, Comp, Conn), ...
    'all_p', 'all_pp', 'all_ph', 'all_Bio', 'plant_Bio', 'herb_Bio') ;
yyaxis left
plot(drange,all_p(drange,:),'bo') ;
hold on
plot(drange,mean(all_p(drange,:),2)) ;
hold on
ylabel('species persistence') ;
axis([min(drange) Inf 0 1.0]) ;

yyaxis right
plot(drange,all_Bio(drange,:),'ro') ;    
hold on
if TwoLayers
    plot(drange,mean(plant_Bio(drange,:),2),'--') ;    
    hold on
    plot(drange,mean(herb_Bio(drange,:),2),'-.') ;    
    hold on
end
plot(drange,mean(all_Bio(drange,:),2)) ;    
axis([min(drange) Inf 0 Inf]) ;
ylabel('Total biomass') ;
xlabel('species richness') ;

title(sprintf('Hill=%d, Norm=%d, Comp=%d, Conn=%4.2f', Hill, Norm, Comp, Conn)) ;
end

if test_case==4
Hill = 2 ;
Norm = 0 ;
Comp = 1 ;

%figure ;
subplot(2,2,4)
all_p = zeros(drange(end),replicates) ;
all_pp = all_p ;
all_ph = all_p ;
all_Bio = all_p ; 
plant_Bio = all_p ;
herb_Bio = all_p ;

for r=1:replicates
    r
    for S=drange
       [p, pp, ph, T, Y] = test_persistence(S, Hill, Norm, Comp, Conn, CON, TwoLayers, 0, 0) ;
       all_p(S,r) = p ;
       all_pp(S,r) = pp ;
       all_ph(S,r) = ph ;
       all_Bio(S,r) = sum(Y(end,:)) ;
       plant_Bio(S,r) = sum(Y(end,1:round(S/2))) ;
       herb_Bio(S,r) = all_Bio(S,r) - plant_Bio(S,r) ;
    end
end
save(sprintf('H%.1fN%dC%dc%.2f.B1.mat', Hill, Norm, Comp, Conn), ...
    'all_p', 'all_pp', 'all_ph', 'all_Bio', 'plant_Bio', 'herb_Bio') ;
yyaxis left
plot(drange,all_p(drange,:),'bo') ;
hold on
plot(drange,mean(all_p(drange,:),2)) ;
hold on
ylabel('species persistence') ;
axis([min(drange) Inf 0 1.0]) ;

yyaxis right
plot(drange,all_Bio(drange,:),'ro') ;    
hold on
if TwoLayers
    plot(drange,mean(plant_Bio(drange,:),2),'--') ;    
    hold on
    plot(drange,mean(herb_Bio(drange,:),2),'-.') ;    
    hold on
end
plot(drange,mean(all_Bio(drange,:),2)) ;    
axis([min(drange) Inf 0 Inf]) ;
ylabel('Total biomass') ;
xlabel('species richness') ;

title(sprintf('Hill=%d, Norm=%d, Comp=%d, Conn=%4.2f', Hill, Norm, Comp, Conn)) ;
end
