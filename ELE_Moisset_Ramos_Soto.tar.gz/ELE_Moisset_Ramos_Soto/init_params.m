function init_params ( A , Hill, Norm, Comp, connectance)
% Hill == 1 means type II functional response
% Norm == 1 means normalizing preferences
% Comp == 1 means all spp compete among them

global Adj ialpha C r I nz_idx beta h ;
S=length(A) ;
Adj = A ;
nz_idx = find(Adj) ;
C = Adj*0.0 ;
ialpha = C ;
nz_qty = length(nz_idx) ;
C(nz_idx) =  rand(nz_qty,1)*(3.0-2.0) + 2.0;
ialpha(nz_idx) = 1.0./(rand(nz_qty,1)*(1.0-0.1) + 0.1);
basals=sum(A)==0 ;
 
r = -(rand(S,1)*(0.2-0.001) + 0.001);
r(basals) = rand(sum(basals),1)*(0.5-0.3) + 0.3;

I = diag(sparse(rand(S,1))*(2.0-1.0) + 1.0);
h = Hill ;
beta = 1.0 ;

if Comp == 1
   tmp = rand(S,S) <= connectance ;
   tmp = tmp.*(1-eye(S)) ;
   nz_tmp = find(tmp) ;
   I(nz_tmp) = (rand(length(nz_tmp),1))*(2.0-1.0) + 1.0 ;
end
I = sparse(I) ;

if Norm == 1
    C = C * diag(1./(sum(A)+realmin)) ;
end

end
