max_p = 1.0 ;
min_p = 1e-3;
max_B = 3 ;
min_B = 1e-2 ;

grey_light = [0.5,0.5,0.5] ;
grey_dark = [0.3,0.3,0.3] ;
green = [0,0.8,0] ;
red = [0.8,0,0] ;
black = [0,0,0] ;

filename = 'H1.0N0C0c0.20.B1.mat'
load(filename)
drange = 5:size(all_Bio,1) ;

fh = figure ;
set(fh,'defaultAxesColorOrder',[black; black]);
[ha, pos] = tight_subplot(1, 2, [0.03 0.02], 0.1, 0.1) ;
axes(ha(1)) ;
yyaxis left
options = struct('handle', fh, 'color_area', [0,0.5,0], 'color_line', ...
                 grey_dark, 'error','c95','alpha', 0.5, 'line_width', 2,...
                 'x_axis', drange) ;
%errorbar(drange,mean(all_pp(drange,:),2),(std(all_pp(drange,:)')/sqrt(size(all_pp,2)))', 'go')
plot_areaerrorbar(all_pp(drange,:)',options)
t = annotation('textbox', [0.44, 0.8, 0.1, 0.1], 'String', "A")
t.LineStyle = 'none';
t.FontUnits = 'normalized';
t.FontSize = 0.04;

t = annotation('textbox', [0.85, 0.8, 0.1, 0.1], 'String', "B")
t.LineStyle = 'none';
t.FontUnits = 'normalized';
t.FontSize = 0.04;

hold on
%errorbar(drange,mean(all_ph(drange,:),2),(std(all_ph(drange,:)')/sqrt(size(all_ph,2)))', 'ro')
options.color_area = red ;
plot_areaerrorbar(all_ph(drange,:)',options)
%set(gca, 'YScale', 'log', 'XScale', 'log') ;
ylabel('Species persistence') ;
axis([min(drange) Inf min_p max_p]) ;
yyaxis right
%plot(drange,mean(plant_Bio(drange,:),2),'-g') ;    
options.color_area = grey_light ;
options.color_line = [121 189 119]/255 ;
options.line_width = 2 ;
plot_areaerrorbar(plant_Bio(drange,:)', options) ;
hold on
%plot(drange, mean(herb_Bio(drange,:),2),'-r') ;    
options.color_line = [223 117 119]/255 ;
plot_areaerrorbar(herb_Bio(drange,:)', options) ;
hold on
%plot(drange,mean(all_Bio(drange,:),2), '-k') ;    
axis([min(drange) Inf min_B max_B]) ;
set(gca,'YTickLabel',[]);
%set(gca,'XTickLabel',[]);
%%setgca, 'YScale', 'log', 'XScale', 'log') ;
%ylabel('Total biomass') ;
xlabel('Species richness') ;
%title(filename) ;

%%
filename = 'H1.0N0C1c0.20.B1.mat'
load(filename)
axes(ha(2)) ;
yyaxis left
options = struct('handle', fh, 'color_area', [0,0.5,0], 'color_line', ...
                 grey_dark, 'error','c95','alpha', 0.5, 'line_width', 2,...
                 'x_axis', drange) ;
%errorbar(drange,mean(all_pp(drange,:),2),(std(all_pp(drange,:)')/sqrt(size(all_pp,2)))', 'go')
plot_areaerrorbar(all_pp(drange,:)',options)
hold on
%errorbar(drange,mean(all_ph(drange,:),2),(std(all_ph(drange,:)')/sqrt(size(all_ph,2)))', 'ro')
options.color_area = red ;
plot_areaerrorbar(all_ph(drange,:)',options)
%set(gca, 'YScale', 'log', 'XScale', 'log') ;
%ylabel('Species persistence') ;
axis([min(drange) Inf min_p max_p]) ;
set(gca,'YTickLabel',[]);
%set(gca,'XTickLabel',[]);
yyaxis right
%plot(drange,mean(plant_Bio(drange,:),2),'-g') ;    
options.color_area = grey_light ;
options.color_line = [121 189 119]/255 ;
options.line_width = 2 ;
plot_areaerrorbar(plant_Bio(drange,:)', options) ;
hold on
%plot(drange, mean(herb_Bio(drange,:),2),'-r') ;    
options.color_line = [223 117 119]/255 ;
plot_areaerrorbar(herb_Bio(drange,:)', options) ;
hold on
%plot(drange,mean(all_Bio(drange,:),2), '-k') ;    
axis([min(drange) Inf min_B max_B]) ;
%%setgca, 'YScale', 'log', 'XScale', 'log') ;
ylabel('Total biomass') ;
xlabel('Species richness') ;
%title(filename) ;


