function dX = rhs(~,X)
global Adj ialpha C r I beta nz_idx h;

denominator = ialpha.^h + Adj * diag(Adj' * abs(X).^h) ;
numerator = diag(abs(X).^h) * C * diag(X) ;

tmp = C ;
tmp(nz_idx) = numerator(nz_idx) ./ denominator(nz_idx) ;

dX = (r - I*X).*X - sum(tmp,2) + beta * sum(tmp,1)';

end
