function [pers, pers_p, pers_h, T, Y] = test_persistence(S, Hill, Norm, Comp, Conn, CON, TwoLayers, seed, animal_zero)
% tests effects of adding competition (and hence consistency) to the thebault
% and fontaine 2010 model (TF).
%TwoLayer == 1 means use a foodweb with two layers (basals and hebivores)

global Adj ... % 0-1 djacency matrix Adj(i,j)==1 iif i is eaten by j
       nz_idx ...% vector of linear positions of Adj which are non zero
       ialpha ...% sparse SxS. Nonzero elements are inverse of alpha_{ij}
       C ...    % sparse SxS. Nonzero elements are c_{ij} of TF
       r ...   % Sx1 reproductive rate
       I ...   % SxS competition 
       beta... % conversion efficiency
       h % Hill exponent of functional response

if seed > 0
   rng(seed) ;
end

if TwoLayers
    A = GenTwoLayer(Conn, S);
else
    basal_qty = 0 ;
    while basal_qty > 4 || basal_qty < 3
       A = TheGenNicheModel(Conn,S,CON);
       basal_qty = sum( sum(A)==0 ) ; 
   end
end
init_params(A, Hill, Norm, Comp, Conn) ;

initial_conditions = rand(S,1)*(0.1-1e-10) + 1e-11 ;
if animal_zero
   initial_conditions(round(S/2)+1:end) = 0 ;
end

tspan = [0:10:2500.0] ;

[T, Y] = ode15s(@rhs,tspan, initial_conditions, odeset('RelTol',1e-6,'AbsTol',1e-13, 'NonNegative', 1:(S))) ;
%[T, Y] = ode45(@rhs,tspan, initial_conditions, odeset('RelTol',1e-6,'AbsTol',1e-13,'NonNegative', 1:(S))) ;
pers = 1-sum(Y(end,:)<1e-11,2)/(S) ;
if TwoLayers
    p_qty = round(S/2) ;
    pers_p = 1-sum(Y(end,1:p_qty)<1e-11,2)/(p_qty) ;
    pers_h = 1-sum(Y(end,p_qty+1:end)<1e-11,2)/(S-p_qty) ;
else
    pers_p = 0;
    pers_h = 0;
end
end
