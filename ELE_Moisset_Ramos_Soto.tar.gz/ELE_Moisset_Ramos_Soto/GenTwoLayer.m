function A = GenTwoLayer(Conn, S)
% Create food web with only two layers.
% Total number of species S and connectance Conn

p_qty = round(S/2) ;
h_qty = S - p_qty ;

A = rand(p_qty,h_qty) <= Conn ;
A = [zeros(p_qty), A ; zeros(h_qty,S)] ;
A = sparse(A) ;
end